const fs = require('fs');
const path = require('path');

// Simple obfuscation function
function obfuscateCode(code) {
    // Replace variable names with random strings
    const varMap = new Map();
    let counter = 0;
    
    // Generate random variable names
    function getRandomVar() {
        return '_0x' + Math.random().toString(36).substr(2, 8);
    }
    
    // Obfuscate common patterns
    code = code
        // Replace console.log with empty function
        .replace(/console\.log\([^)]*\);?/g, '')
        // Replace comments
        .replace(/\/\*[\s\S]*?\*\//g, '')
        .replace(/\/\/.*$/gm, '')
        // Minify whitespace
        .replace(/\s+/g, ' ')
        .replace(/;\s*}/g, ';}')
        .replace(/{\s*/g, '{')
        .replace(/}\s*/g, '}')
        // Replace common variable names
        .replace(/\bbudget\b/g, '_0xa1b2c3')
        .replace(/\bcpu\b/g, '_0xd4e5f6')
        .replace(/\bgame\b/g, '_0xg7h8i9')
        .replace(/\bconfig\b/g, '_0xj1k2l3')
        .replace(/\bcomponent\b/g, '_0xm4n5o6')
        .replace(/\bprice\b/g, '_0xp7q8r9')
        // Add security system and fake functions
        .replace(/^/, `
function _0xcheck(){return!0;}function _0xverify(){return!0;}
function _0xsecurity(){
    const _0xdomains = ['localhost','truongphat.com','truongphatcomputer.com','127.0.0.1'];
    const _0xcurrent = window.location.hostname;
    const _0xallowed = _0xdomains.some(d => _0xcurrent.includes(d) || d.includes(_0xcurrent));
    if (!_0xallowed) {
        document.body.innerHTML = '<div style="position:fixed;top:0;left:0;width:100%;height:100%;background:#dc2626;color:white;display:flex;align-items:center;justify-content:center;z-index:999999;"><h1>🚫 DOMAIN KHÔNG HỢP LỆ!</h1></div>';
        throw new Error('Domain not allowed');
    }
    return!0;
}
_0xsecurity();
window.addEventListener('contextmenu', e => e.preventDefault());
window.addEventListener('keydown', e => {
    if (e.key === 'F12' || (e.ctrlKey && e.shiftKey && e.key === 'I') || (e.ctrlKey && e.key === 'u')) {
        e.preventDefault();
        document.body.innerHTML = '<div style="position:fixed;top:0;left:0;width:100%;height:100%;background:#dc2626;color:white;display:flex;align-items:center;justify-content:center;z-index:999999;"><h1>🚫 DEVTOOLS BỊ CHẶN!</h1></div>';
    }
});
`)
        // Encode strings (using Buffer instead of btoa)
        .replace(/"([^"]+)"/g, (match, str) => {
            if (str.length > 50) return match; // Skip long strings
            const encoded = Buffer.from(str).toString('base64');
            return `Buffer.from("${encoded}","base64").toString()`;
        });
    
    return code;
}

// Obfuscate main files
const filesToObfuscate = [
    'complete-pc-builder.js',
    'index.html'
];

const distDir = 'dist';
if (!fs.existsSync(distDir)) {
    fs.mkdirSync(distDir);
}

filesToObfuscate.forEach(file => {
    if (fs.existsSync(file)) {
        const content = fs.readFileSync(file, 'utf8');
        const obfuscated = obfuscateCode(content);
        
        const outputFile = path.join(distDir, file);
        fs.writeFileSync(outputFile, obfuscated);
        console.log(`✅ Obfuscated: ${file} -> ${outputFile}`);
    }
});

// Copy other necessary files
const filesToCopy = [
    'server.js',
    'package.json',
    'package-lock.json',
    'components-overview.html',
    'main.html',
    'manifest.json'
];

filesToCopy.forEach(file => {
    if (fs.existsSync(file)) {
        fs.copyFileSync(file, path.join(distDir, file));
        console.log(`📁 Copied: ${file}`);
    }
});

// Copy directories
const dirsToCopy = ['js', 'images', 'image'];
dirsToCopy.forEach(dir => {
    if (fs.existsSync(dir)) {
        copyDir(dir, path.join(distDir, dir));
        console.log(`📁 Copied directory: ${dir}`);
    }
});

function copyDir(src, dest) {
    if (!fs.existsSync(dest)) {
        fs.mkdirSync(dest, { recursive: true });
    }
    
    const items = fs.readdirSync(src);
    items.forEach(item => {
        const srcPath = path.join(src, item);
        const destPath = path.join(dest, item);
        
        if (fs.statSync(srcPath).isDirectory()) {
            copyDir(srcPath, destPath);
        } else {
            fs.copyFileSync(srcPath, destPath);
        }
    });
}

console.log('\n🔒 Obfuscation completed! Deploy the /dist folder instead.');
console.log('Original source code is protected, only obfuscated version in /dist'); 